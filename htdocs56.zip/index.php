<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="/docs/4.0/assets/img/favicons/favicon.ico">

    <title>ABERTOOL</title>

    <link rel="canonical" href="https://getbootstrap.com/docs/4.0/examples/cover/">

    <!-- Bootstrap core CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="style/cover.css" rel="stylesheet">
  </head>

  <body class="text-center">

	  
    <div class="cover-container d-flex h-100 p-3 mx-auto flex-column">

      <main role="main" class="inner cover container1 "><br><br>
	  <img src="/style/logo.png" alt="CoolBrand"><br><br>
	  <br>------------------------------------------------------------------------
        <p class="cover-heading">
		
		
		<?php
    $f_contents = file("style/random.txt"); 
    $line = $f_contents[rand(0, count($f_contents) - 1)];
	print $line;
?> <br>------------------------------------------------------------------------</p>



<?php
function delete_directory($dirPath){
        $dir = $dirPath;   
        if(is_dir($dir)){
            $files = new RecursiveIteratorIterator(
                new RecursiveDirectoryIterator($dir, RecursiveDirectoryIterator::SKIP_DOTS), RecursiveIteratorIterator::CHILD_FIRST
            );
            foreach($files as $file){
                if ($file->isDir()){
                    rmdir($file->getRealPath());
                }else{
                    unlink($file->getRealPath());
                }
            }
            rmdir($dir);
        }
    }
function tag_contents($string, $tag_open, $tag_close)
{
    foreach (explode($tag_open, $string) as $key => $value)
    {
        if (strpos($value, $tag_close) !== false)
        {
            $result[] = substr($value, 0, strpos($value, $tag_close));;
        }
    }
    return $result;
}
$url='https://github.com/tonquanganh/abertool/blob/main/version.html'; // tạo biến url cần lấy
$lines_array=file($url); // dùng hàm file() lấy dữ liệu theo url
$lines_string=implode('',$lines_array); // chuyển dữ liệu lấy được kiểu mảng thành một biến string
$newversion = tag_contents($lines_string, "@1@", "@2@"); $newversion = $newversion[0];
echo "Phiên bản mới nhất trên hệ thống là: <h2>".$newversion."</h2>";
$fp = @fopen('style/version.txt', "r");
if (!$fp) {echo 'File not found';}
else
{$nowversion = fread($fp, filesize('style/version.txt'));
if ($nowversion != $newversion)
{echo "<br>Phiên bản trước đó là: <h2 style='color:red;'>".$nowversion."</h2>";;

$file = 'https://github.com/tonquanganh/abertool/raw/main/'.$newversion;
$newfile = $_SERVER['DOCUMENT_ROOT'] . '/htdocs.zip';

if ( copy($file, $newfile) ) {
    echo "";
}else{
    echo "<br>TẢI FILE VỀ TẤT BẠI!";
}
// folder path to delete all files
$files = glob("mhl/*");
// delete all the files from the list 
foreach($files as $file){
 if(is_file($file)){
 unlink($file);
 }
}

// folder path to delete all files
$files = glob("msgdl/*");
// delete all the files from the list 
foreach($files as $file){
 if(is_file($file)){
 unlink($file);
 }
}

// folder path to delete all files
$files = glob("msgbt/*");
// delete all the files from the list 
foreach($files as $file){
 if(is_file($file)){
 unlink($file);
 }
}

$zip = new ZipArchive;
$res = $zip->open('htdocs.zip');
if ($res === TRUE) {

  $zip->extractTo($_SERVER['DOCUMENT_ROOT']);
  $zip->close();

  echo "<br>Đã cập nhật phiên bản mới nhất xong!";
} else {
  echo '<br>LỖI!';
}
unlink("htdocs.zip");



$addnewver = fopen('style/version.txt', 'w'); //mở file ở chế độ write-only
fwrite($addnewver, $newversion);
fclose($addnewver);
}
else{echo "<br>Phiên bản hiện tại là: <h2 style='color:lime;'>". $nowversion."</h2>";}
}
fclose($fp);






?>

<br><br>


        <p class="lead">Chọn bệnh viện mà bạn muốn tới.<br>Sẽ có sự khác biệt giữa các nơi, nên, hãy chọn đúng...</p>
        <p class="lead">
          <a href="mhl/" class="btn btn-lg btn-secondary">Mắt Hoa Lư</a> <a href="msgdl/" class="btn btn-lg btn-secondary">Mắt Sài Gòn Đà Lạt</a> <a href="mstbt/" class="btn btn-lg btn-secondary">Mắt Sông Tiền Bến Tre</a>
        </p>
		 <p>Source by @aberto. </p>
      </main>

      <footer class="mastfoot mt-auto">
        <div class="inner">
         
		  <img alt='Hits' src='https://hits.sh/github.com/tonquanganh/abertoolhit.svg?label=l%C6%B0%E1%BB%A3t%20xem&color=0080c8'/>
        </div>
      </footer>
    </div>


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script>window.jQuery || document.write('<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"><\/script>')</script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
  </body>
</html>
