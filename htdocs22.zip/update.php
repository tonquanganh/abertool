<?php
function tag_contents($string, $tag_open, $tag_close)
{
    foreach (explode($tag_open, $string) as $key => $value)
    {
        if (strpos($value, $tag_close) !== false)
        {
            $result[] = substr($value, 0, strpos($value, $tag_close));;
        }
    }
    return $result;
}
$url='https://github.com/tonquanganh/abertool/blob/main/version.html'; // tạo biến url cần lấy
$lines_array=file($url); // dùng hàm file() lấy dữ liệu theo url
$lines_string=implode('',$lines_array); // chuyển dữ liệu lấy được kiểu mảng thành một biến string
$newversion = tag_contents($lines_string, "@1@", "@2@"); $newversion = $newversion[0];
echo "Phiên bản mới là: ".$newversion;
$fp = @fopen('style/version.txt', "r");
if (!$fp) {echo 'File not found';}
else
{$nowversion = fread($fp, filesize('style/version.txt'));
if ($nowversion != $newversion)
{echo "<br>Phiên bản trước đó là: ".$nowversion;
echo "<br>Đã cập nhật phiên bản mới nhất xong!";



$file = 'https://github.com/tonquanganh/abertool/raw/main/'.$newversion;
$newfile = $_SERVER['DOCUMENT_ROOT'] . '/files/htdocs.zip';

if ( copy($file, $newfile) ) {
    echo "TẢI FILE VỀ THÀNH CÔNG!";
}else{
    echo "TẢI FILE VỀ TẤT BẠI!";
}

$zip = new ZipArchive;
$res = $zip->open('files/htdocs.zip');
if ($res === TRUE) {
  $zip->extractTo('files/');
  $zip->close();
  echo 'GIẢI NÉN THÀNH CÔNG!';
} else {
  echo 'LỖI!';
}
unlink("files/htdocs.zip");



$addnewver = fopen('style/version.txt', 'w'); //mở file ở chế độ write-only
fwrite($addnewver, $newversion);
fclose($addnewver);
}
else{echo "<br>Phiên bản hiện tại là: ". $nowversion;}
}
fclose($fp);






?>