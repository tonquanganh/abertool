<?php include 'style/header.php';?>
<div class="p-2 m-md-3 rounded shadow-sm bg-white">Chào buổi chiều!<br>Chúc một ngày làm việc vui vẻ <3 </div>
<?php include 'style/footer.php';?>